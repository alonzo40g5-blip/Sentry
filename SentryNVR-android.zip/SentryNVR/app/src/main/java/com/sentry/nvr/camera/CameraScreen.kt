package com.sentry.nvr.camera

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Paint
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.sentry.nvr.detect.Box as DetBox
import com.sentry.nvr.detect.Detector
import java.util.concurrent.Executors
import kotlin.math.min

/** Live rear-camera preview with YOLO detections drawn on top. */
@Composable
fun CameraScreen(
    detector: Detector?,
    onInference: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var boxes by remember { mutableStateOf<List<DetBox>>(emptyList()) }
    var srcW by remember { mutableStateOf(1) }
    var srcH by remember { mutableStateOf(1) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) { onDispose { executor.shutdown() } }

    Box(modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FIT_CENTER
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                }
                val future = ProcessCameraProvider.getInstance(ctx)
                future.addListener({
                    val provider = future.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .build()
                    analysis.setAnalyzer(executor) { proxy ->
                        try {
                            if (detector != null) {
                                val bmp = proxy.toBitmap()
                                val rotated = rotate(bmp, proxy.imageInfo.rotationDegrees)
                                val t0 = System.currentTimeMillis()
                                val result = detector.detect(rotated)
                                onInference(System.currentTimeMillis() - t0)
                                srcW = rotated.width
                                srcH = rotated.height
                                boxes = result
                            }
                        } catch (_: Throwable) {
                        } finally {
                            proxy.close()
                        }
                    }
                    try {
                        provider.unbindAll()
                        provider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            analysis
                        )
                    } catch (_: Exception) {
                    }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            }
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
            val scale = min(size.width / srcW, size.height / srcH)
            val dx = (size.width - srcW * scale) / 2f
            val dy = (size.height - srcH * scale) / 2f
            boxes.forEach { b ->
                val left = dx + b.x1 * srcW * scale
                val top = dy + b.y1 * srcH * scale
                val right = dx + b.x2 * srcW * scale
                val bottom = dy + b.y2 * srcH * scale
                val col = when (b.label) {
                    "person" -> Color(0xFF2EE6A6)
                    "car", "truck", "bus", "motorcycle", "bicycle", "train" -> Color(0xFF3F86FF)
                    else -> Color(0xFFF5A524)
                }
                drawRect(
                    color = col,
                    topLeft = Offset(left, top),
                    size = Size(right - left, bottom - top),
                    style = Stroke(width = 4f)
                )
                val label = "${b.label} ${(b.cnf * 100).toInt()}%"
                val txt = Paint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = 34f
                    isFakeBoldText = true
                }
                val bg = Paint().apply { color = col.toArgb() }
                val tw = txt.measureText(label)
                drawContext.canvas.nativeCanvas.drawRect(left, top - 44f, left + tw + 16f, top, bg)
                drawContext.canvas.nativeCanvas.drawText(label, left + 8f, top - 14f, txt)
            }
        }
    }
}

private fun rotate(src: Bitmap, degrees: Int): Bitmap {
    if (degrees == 0) return src
    val m = Matrix().apply { postRotate(degrees.toFloat()) }
    return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
}
