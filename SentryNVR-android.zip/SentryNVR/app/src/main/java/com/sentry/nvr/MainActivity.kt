package com.sentry.nvr

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Dvr
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.sentry.nvr.camera.CameraScreen
import com.sentry.nvr.cameras.CamerasScreen
import com.sentry.nvr.detect.Detector
import com.sentry.nvr.theme.SentryTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SentryTheme { App() } }
    }
}

private sealed interface DetState {
    data object Loading : DetState
    data class Ready(val detector: Detector) : DetState
    data object Missing : DetState
}

@Composable
private fun App() {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var inferMs by remember { mutableLongStateOf(0L) }

    var hasCamera by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCamera = granted }

    LaunchedEffect(Unit) {
        if (!hasCamera) permLauncher.launch(Manifest.permission.CAMERA)
    }

    // Load the YOLO model off the main thread. Missing model -> app still runs.
    val det by produceState<DetState>(DetState.Loading) {
        value = withContext(Dispatchers.Default) {
            try {
                DetState.Ready(Detector(context.applicationContext))
            } catch (_: Throwable) {
                DetState.Missing
            }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Videocam, null) },
                    label = { Text("Live (AI)") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.Dvr, null) },
                    label = { Text("Cameras") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Info, null) },
                    label = { Text("About") }
                )
            }
        }
    ) { padding ->
        Surface(
            modifier = Modifier.fillMaxSize().padding(padding),
            color = MaterialTheme.colorScheme.background
        ) {
            when (tab) {
                0 -> LiveTab(det, hasCamera, inferMs) { inferMs = it }
                1 -> CamerasScreen()
                else -> AboutTab()
            }
        }
    }
}

@Composable
private fun LiveTab(det: DetState, hasCamera: Boolean, inferMs: Long, onInfer: (Long) -> Unit) {
    Box(Modifier.fillMaxSize()) {
        if (!hasCamera) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Camera permission needed", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Grant camera access to run live detection.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            return
        }
        val detector = (det as? DetState.Ready)?.detector
        CameraScreen(detector = detector, onInference = onInfer, modifier = Modifier.fillMaxSize())

        // Status pill (top-left)
        StatusPill(
            when (det) {
                is DetState.Loading -> "Loading model…"
                is DetState.Missing -> "Model missing — camera only"
                is DetState.Ready -> "YOLOv8n · ${inferMs}ms"
            },
            good = det is DetState.Ready
        )
    }
}

@Composable
private fun StatusPill(text: String, good: Boolean) {
    Box(Modifier.padding(12.dp)) {
        Surface(
            color = if (good) Color(0xCC10B981) else Color(0xCCF5A524),
            shape = MaterialTheme.shapes.large
        ) {
            Text(
                text,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun AboutTab() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Sentry NVR", style = MaterialTheme.typography.headlineSmall)
        Text("v0.1.0 — preview build", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            "Live (AI): runs YOLOv8 object detection on your phone camera, fully on-device.\n\n" +
                "Cameras: add an IP camera by its RTSP address to view its live stream.\n\n" +
                "Recognition of number plates, vehicle make/model, and faces are the next models " +
                "to add on top of this detection layer. Any such features must be used lawfully — " +
                "face recognition in particular is restricted under GDPR and the EU AI Act, so it " +
                "should ship off by default and only be enabled where permitted.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
