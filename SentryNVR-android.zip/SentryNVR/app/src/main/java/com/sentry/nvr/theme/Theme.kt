package com.sentry.nvr.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Violet = Color(0xFF5A47EC)
val Bg = Color(0xFFEDF0F7)
val SurfaceW = Color(0xFFFFFFFF)
val Ink = Color(0xFF161A23)
val Muted = Color(0xFF8B94A6)
val Green = Color(0xFF10B981)
val Amber = Color(0xFFF5A524)
val VehicleBlue = Color(0xFF2F6BFF)

private val scheme = lightColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    secondary = Green,
    background = Bg,
    onBackground = Ink,
    surface = SurfaceW,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF3F5FB),
    onSurfaceVariant = Muted,
)

@Composable
fun SentryTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = scheme, content = content)
