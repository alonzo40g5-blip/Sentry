# Sentry NVR — Android (phone camera + YOLO + IP cameras)

A real Android app:

- **Live (AI)** — runs **YOLOv8** object detection on your **phone camera**, fully on-device
  (LiteRT/TFLite + CameraX). Draws live boxes for people, cars, and 80 COCO classes.
- **Cameras** — add an **IP camera** by its **RTSP** address and view its live stream (Media3).

> Number-plate, vehicle make/model, and face recognition are the **next** models to add on top
> of this detection layer. Face recognition is legally restricted (GDPR / EU AI Act) and should
> ship **off by default** and only be enabled where lawful.

---

## How you get the APK (no local tools needed)

You can't run a compiler in a browser, and this repo doesn't ship a prebuilt APK — **GitHub builds
it for you** with the included workflow. The build even downloads the YOLO model automatically.

1. **Create a new repository** on GitHub (e.g. `sentry-nvr`).
2. **Upload these files** (drag the whole folder into the GitHub web uploader, or `git push`).
3. Go to the **Actions** tab → the **Build APK** workflow runs automatically. Wait ~5–10 min.
4. Open the finished run → **Artifacts** → download **`sentry-nvr-debug-apk`**.
5. Unzip it, copy **`app-debug.apk`** to your phone, and install it
   (enable *Install unknown apps* for your file manager / browser when prompted).
6. Open the app, allow the camera, and point it at people or cars — YOLO boxes appear live.

### git push version
```bash
git init
git add .
git commit -m "Sentry NVR: phone camera + YOLO + IP cameras"
git branch -M main
git remote add origin https://github.com/<you>/sentry-nvr.git
git push -u origin main
```

---

## Build locally instead (Android Studio)

1. Install **Android Studio** (latest). Open this folder as a project; let it sync Gradle.
2. Add the model file: export it once and drop it in `app/src/main/assets/`:
   ```bash
   pip install ultralytics
   yolo export model=yolov8n.pt format=tflite imgsz=640
   cp yolov8n_saved_model/yolov8n_float32.tflite app/src/main/assets/
   ```
3. Plug in a phone (USB debugging on) and press **Run**.

Android Studio generates the Gradle wrapper on first sync, so `./gradlew` works locally too.

---

## What's inside

```
app/src/main/java/com/sentry/nvr/
├── MainActivity.kt          app shell, bottom nav, camera permission, model loading
├── detect/Detector.kt       YOLO on LiteRT/TFLite: preprocess, infer, decode, NMS
├── camera/CameraScreen.kt   CameraX preview + live detection overlay (phone camera)
├── cameras/CamerasScreen.kt add & view IP cameras over RTSP (Media3 ExoPlayer)
└── theme/Theme.kt           light "Aurora" colours
.github/workflows/build-apk.yml   fetches YOLO -> tflite, builds the APK, uploads it
app/src/main/assets/labels.txt    the 80 COCO class names
```

Model: **YOLOv8n** exported to a 640×640 float32 `.tflite` (~12 MB), bundled at build time.
Swap to `yolo11n` or `yolo26n` by changing the model name in the workflow.

---

## Honest notes / troubleshooting

- **This is a fresh project I can't compile in my environment**, so a first build may need a minor
  version bump (AGP / Kotlin / a library). The Actions log points at the exact line if so — send
  it to me and I'll fix it.
- **Box alignment**: detections are mapped to the preview with fit-center math. On some phones the
  analysis and preview aspect ratios differ slightly, nudging boxes a few pixels. Tunable.
- **Detection is heavy at full frame rate** — CameraX uses *keep-only-latest*, so it analyses as
  fast as the phone allows and skips frames rather than lagging. Expect ~10–30 fps on a mid phone.
- **RTSP** streams vary wildly; if a camera won't play in Media3, LibVLC (`libvlc-all`) is the
  more tolerant fallback. Running YOLO on RTSP frames (not just viewing) is the next step.
- If the CI model export ever fails (TensorFlow version drift), use the **local export** above and
  commit the `.tflite` — the app reads it from assets either way.

---

## Roadmap to production

1. ✅ Phone-camera YOLO (this build) — prove the AI works on-device.
2. Run YOLO on **IP-camera** frames (extract frames from the RTSP pipeline).
3. Add **ANPR** (plate detect + OCR) and **vehicle make/model** on the cropped detections.
4. Add **face recognition** for *enrolled* people — off by default, consent-gated.
5. Move recording + the searchable event database to an always-on **box** (the phone becomes the
   viewer). This is the real architecture; the phone can't record 24/7.
