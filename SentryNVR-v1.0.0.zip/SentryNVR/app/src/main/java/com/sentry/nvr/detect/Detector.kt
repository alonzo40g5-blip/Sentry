package com.sentry.nvr.detect

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/** One detected object; coordinates normalised 0..1 relative to the full frame. */
data class Box(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val cnf: Float, val cls: Int, val label: String
)

/**
 * Runs a YOLO model (LiteRT/TFLite) on a Bitmap. The model file is provided at runtime
 * (downloaded or imported into internal storage). It inspects the model's own input and
 * output tensor shapes, so it works whether the export is NHWC or NCHW and whether the
 * output is [1,84,8400] or [1,8400,84].
 */
class Detector(
    context: Context,
    modelFile: File,
    labelPath: String = "labels.txt",
) {
    private val interpreter: Interpreter
    private val labels = mutableListOf<String>()

    private var inW = 0
    private var inH = 0
    private var nhwc = true
    private var dim1 = 0
    private var dim2 = 0

    init {
        interpreter = Interpreter(loadModel(modelFile), Interpreter.Options().apply { numThreads = 4 })

        val inShape = interpreter.getInputTensor(0).shape()
        nhwc = inShape[3] == 3
        inH = if (nhwc) inShape[1] else inShape[2]
        inW = if (nhwc) inShape[2] else inShape[3]

        val outShape = interpreter.getOutputTensor(0).shape()
        dim1 = outShape[1]
        dim2 = outShape[2]

        context.assets.open(labelPath).use { s ->
            BufferedReader(InputStreamReader(s)).forEachLine { if (it.isNotBlank()) labels.add(it.trim()) }
        }
    }

    private fun loadModel(file: File): MappedByteBuffer {
        FileInputStream(file).use { fis ->
            return fis.channel.map(FileChannel.MapMode.READ_ONLY, 0, file.length())
        }
    }

    private fun preprocess(frame: Bitmap): ByteBuffer {
        val resized = Bitmap.createScaledBitmap(frame, inW, inH, false)
        val buf = ByteBuffer.allocateDirect(1 * 3 * inH * inW * 4).order(ByteOrder.nativeOrder())
        val px = IntArray(inW * inH)
        resized.getPixels(px, 0, inW, 0, 0, inW, inH)
        if (nhwc) {
            for (p in px) {
                buf.putFloat(((p shr 16) and 0xFF) / 255f)
                buf.putFloat(((p shr 8) and 0xFF) / 255f)
                buf.putFloat((p and 0xFF) / 255f)
            }
        } else {
            for (p in px) buf.putFloat(((p shr 16) and 0xFF) / 255f)
            for (p in px) buf.putFloat(((p shr 8) and 0xFF) / 255f)
            for (p in px) buf.putFloat((p and 0xFF) / 255f)
        }
        buf.rewind()
        return buf
    }

    fun detect(frame: Bitmap): List<Box> {
        if (inW == 0) return emptyList()
        val output = Array(1) { Array(dim1) { FloatArray(dim2) } }
        interpreter.run(preprocess(frame), output)
        return nms(decode(output[0]))
    }

    private fun decode(m: Array<FloatArray>): List<Box> {
        val feat = 4 + labels.size
        val channelsFirst = dim1 == feat
        val anchors = if (channelsFirst) dim2 else dim1
        val out = ArrayList<Box>()
        for (i in 0 until anchors) {
            var best = -1f
            var bestIdx = -1
            for (c in 0 until labels.size) {
                val s = if (channelsFirst) m[4 + c][i] else m[i][4 + c]
                if (s > best) { best = s; bestIdx = c }
            }
            if (best < CONF) continue
            val cx = if (channelsFirst) m[0][i] else m[i][0]
            val cy = if (channelsFirst) m[1][i] else m[i][1]
            val w = if (channelsFirst) m[2][i] else m[i][2]
            val h = if (channelsFirst) m[3][i] else m[i][3]
            out.add(Box(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f, best, bestIdx,
                labels.getOrElse(bestIdx) { "obj" }))
        }
        return out
    }

    private fun nms(boxes: List<Box>): List<Box> {
        val sorted = boxes.sortedByDescending { it.cnf }.toMutableList()
        val kept = ArrayList<Box>()
        while (sorted.isNotEmpty()) {
            val best = sorted.removeAt(0)
            kept.add(best)
            val it = sorted.iterator()
            while (it.hasNext()) if (iou(best, it.next()) > IOU) it.remove()
        }
        return kept
    }

    private fun iou(a: Box, b: Box): Float {
        val x1 = maxOf(a.x1, b.x1); val y1 = maxOf(a.y1, b.y1)
        val x2 = minOf(a.x2, b.x2); val y2 = minOf(a.y2, b.y2)
        val inter = maxOf(0f, x2 - x1) * maxOf(0f, y2 - y1)
        val areaA = (a.x2 - a.x1) * (a.y2 - a.y1)
        val areaB = (b.x2 - b.x1) * (b.y2 - b.y1)
        return inter / (areaA + areaB - inter + 1e-6f)
    }

    fun close() = interpreter.close()

    companion object {
        private const val CONF = 0.3f
        private const val IOU = 0.5f
    }
}
