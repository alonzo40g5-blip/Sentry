package com.sentry.nvr

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dvr
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.sentry.nvr.camera.CameraScreen
import com.sentry.nvr.cameras.CamerasScreen
import com.sentry.nvr.detect.Detector
import com.sentry.nvr.model.ModelScreen
import com.sentry.nvr.model.ModelStore
import com.sentry.nvr.theme.SentryTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SentryTheme { App() } }
    }
}

private sealed interface DetState {
    data object Loading : DetState
    data object NoModel : DetState
    data class Ready(val detector: Detector) : DetState
    data class Error(val msg: String) : DetState
}

@Composable
private fun App() {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var inferMs by remember { mutableLongStateOf(0L) }
    var modelVersion by remember { mutableIntStateOf(0) }

    var hasCamera by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCamera = granted }

    LaunchedEffect(Unit) { if (!hasCamera) permLauncher.launch(Manifest.permission.CAMERA) }

    // Reloads whenever the model changes (download / import / remove)
    val det by produceState<DetState>(DetState.Loading, modelVersion) {
        value = DetState.Loading
        value = withContext(Dispatchers.Default) {
            if (!ModelStore.exists(context)) DetState.NoModel
            else try {
                DetState.Ready(Detector(context.applicationContext, ModelStore.modelFile(context)))
            } catch (e: Throwable) {
                DetState.Error(e.message ?: "Failed to load model")
            }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 },
                    icon = { Icon(Icons.Filled.Videocam, null) }, label = { Text("Live (AI)") })
                NavigationBarItem(tab == 1, { tab = 1 },
                    icon = { Icon(Icons.Filled.Dvr, null) }, label = { Text("Cameras") })
                NavigationBarItem(tab == 2, { tab = 2 },
                    icon = { Icon(Icons.Filled.Download, null) }, label = { Text("Model") })
                NavigationBarItem(tab == 3, { tab = 3 },
                    icon = { Icon(Icons.Filled.Info, null) }, label = { Text("About") })
            }
        }
    ) { padding ->
        Surface(
            modifier = Modifier.fillMaxSize().padding(padding),
            color = MaterialTheme.colorScheme.background
        ) {
            when (tab) {
                0 -> LiveTab(det, hasCamera, inferMs, onOpenModel = { tab = 2 }) { inferMs = it }
                1 -> CamerasScreen()
                2 -> ModelScreen(onModelChanged = { modelVersion++ })
                else -> AboutTab()
            }
        }
    }
}

@Composable
private fun LiveTab(
    det: DetState,
    hasCamera: Boolean,
    inferMs: Long,
    onOpenModel: () -> Unit,
    onInfer: (Long) -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        if (!hasCamera) {
            CenterMessage("Camera permission needed", "Grant camera access to run live detection.")
            return
        }
        when (det) {
            is DetState.NoModel -> {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("No model installed", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Download or import a YOLO model to start detecting.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(onClick = onOpenModel, modifier = Modifier.padding(top = 14.dp)) {
                        Text("Get model")
                    }
                }
            }
            is DetState.Error -> CenterMessage("Model error", det.msg)
            else -> {
                val detector = (det as? DetState.Ready)?.detector
                CameraScreen(detector = detector, onInference = onInfer, modifier = Modifier.fillMaxSize())
                StatusPill(
                    when (det) {
                        is DetState.Loading -> "Loading model…"
                        is DetState.Ready -> "YOLOv8n · ${inferMs}ms"
                        else -> ""
                    },
                    good = det is DetState.Ready
                )
            }
        }
    }
}

@Composable
private fun CenterMessage(title: String, body: String) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun StatusPill(text: String, good: Boolean) {
    if (text.isBlank()) return
    Box(Modifier.padding(12.dp)) {
        Surface(
            color = if (good) Color(0xCC10B981) else Color(0xCCF5A524),
            shape = MaterialTheme.shapes.large
        ) {
            Text(
                text, color = Color.White, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun AboutTab() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Sentry NVR", style = MaterialTheme.typography.headlineSmall)
        Text("v1.0.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            "Live (AI): runs YOLOv8 object detection on your phone camera, fully on-device.\n\n" +
                "Model: download or import the YOLO model (~12 MB).\n\n" +
                "Cameras: add an IP camera by its RTSP address to view its live stream.\n\n" +
                "Plate, vehicle make/model, and face recognition are the next models to add. Face " +
                "recognition is restricted under GDPR and the EU AI Act — it should ship off by " +
                "default and only be enabled where lawful.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
