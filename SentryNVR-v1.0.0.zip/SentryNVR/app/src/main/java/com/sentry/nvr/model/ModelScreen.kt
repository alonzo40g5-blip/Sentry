package com.sentry.nvr.model

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sentry.nvr.theme.Amber
import com.sentry.nvr.theme.Green
import kotlinx.coroutines.launch

@Composable
fun ModelScreen(onModelChanged: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var url by remember { mutableStateOf(ModelStore.DEFAULT_MODEL_URL) }
    var status by remember { mutableStateOf("") }
    var progress by remember { mutableIntStateOf(-1) }   // -1 = idle, 0..100 = downloading
    var refresh by remember { mutableIntStateOf(0) }

    val present = remember(refresh) { ModelStore.exists(context) }
    val sizeMb = remember(refresh) { ModelStore.sizeMb(context) }
    val busy = progress in 0..100

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) scope.launch {
            status = "Importing…"
            try {
                ModelStore.importFrom(context, uri)
                status = "Model imported ✓"; refresh++; onModelChanged()
            } catch (e: Throwable) {
                status = "Import failed: ${e.message}"
            }
        }
    }

    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("YOLO model", style = MaterialTheme.typography.headlineSmall)

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (present) "Installed" else "Not installed",
                    color = if (present) Green else Amber,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                if (present) Text("Size: $sizeMb", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Text(
            "The app needs a YOLO model (~12 MB) to detect objects. Download it directly, " +
                "or import a .tflite file you already have on your phone.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = url, onValueChange = { url = it },
            label = { Text("Download URL (.tflite)") },
            singleLine = true, enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                scope.launch {
                    progress = 0; status = "Downloading…"
                    try {
                        ModelStore.download(context, url) { p -> progress = p }
                        progress = -1; status = "Model downloaded ✓"; refresh++; onModelChanged()
                    } catch (e: Throwable) {
                        progress = -1; status = "Download failed: ${e.message}"
                    }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Downloading $progress%" else "Download model") }

        if (busy) LinearProgressIndicator(
            progress = { progress / 100f },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedButton(
            onClick = { importLauncher.launch(arrayOf("*/*")) },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Import model file (.tflite)") }

        if (status.isNotBlank()) {
            Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (present && !busy) {
            TextButton(onClick = {
                ModelStore.delete(context); refresh++; onModelChanged(); status = "Model removed"
            }) { Text("Remove model") }
        }
    }
}
