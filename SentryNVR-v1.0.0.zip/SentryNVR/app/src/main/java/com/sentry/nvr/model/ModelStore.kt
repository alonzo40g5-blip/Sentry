package com.sentry.nvr.model

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Stores the YOLO model in the app's private internal storage, obtained at runtime. */
object ModelStore {

    const val DEFAULT_MODEL_URL =
        "https://huggingface.co/squantumengine/yolov8_saved_model/resolve/main/yolov8n_float32.tflite"

    fun modelFile(context: Context): File = File(context.filesDir, "yolov8n_float32.tflite")

    fun exists(context: Context): Boolean = modelFile(context).let { it.exists() && it.length() > 0 }

    fun sizeMb(context: Context): String {
        val f = modelFile(context)
        if (!f.exists()) return "0 MB"
        return String.format("%.1f MB", f.length() / (1024.0 * 1024.0))
    }

    fun delete(context: Context) {
        modelFile(context).takeIf { it.exists() }?.delete()
    }

    /** Downloads the model from a URL into internal storage, reporting 0..100 progress. */
    suspend fun download(context: Context, urlStr: String, onProgress: (Int) -> Unit) =
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = true
                    connectTimeout = 20000
                    readTimeout = 60000
                    setRequestProperty("User-Agent", "SentryNVR")
                }
                conn.connect()
                if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
                val total = conn.contentLengthLong
                val tmp = File(context.filesDir, "model.tmp")
                conn.inputStream.use { input ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(8192)
                        var read = 0L
                        var n: Int
                        while (input.read(buf).also { n = it } != -1) {
                            out.write(buf, 0, n)
                            read += n
                            if (total > 0) onProgress(((read * 100) / total).toInt())
                        }
                    }
                }
                if (tmp.length() < 100_000) throw IOException("Downloaded file too small — wrong URL?")
                val dest = modelFile(context)
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) throw IOException("Could not save model")
            } finally {
                conn?.disconnect()
            }
        }

    /** Copies a user-picked .tflite file into internal storage. */
    suspend fun importFrom(context: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val dest = modelFile(context)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { out -> input.copyTo(out) }
        } ?: throw IOException("Cannot open selected file")
        if (dest.length() < 100_000) {
            dest.delete()
            throw IOException("Selected file too small — is it a .tflite model?")
        }
    }
}
